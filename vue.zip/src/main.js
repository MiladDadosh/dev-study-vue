import Vue from 'vue'
import App from './App.vue'

//global axios
import axios from 'axios'
window.axios = axios


//global vue prototpe bus
const bus = new Vue();
Object.defineProperties(Vue.prototype, {
  $bus: {
    get() {return bus}
  }
});

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
