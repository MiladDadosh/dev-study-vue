<template>
  <div id="app" v-cloak>
    <Home/>
  </div>
</template>

<script>
import Home from './components/Home.vue'

export default {
  name: 'App',
  components: {
    Home
  }
}
</script>

<style lang="scss">
[v-cloak] {display: none;}
*:not(i){transition: all .3s ease}

html,body {
  padding: 0;
  margin: 0;
  width: 100%;
  height: 100%;
  max-width: 1046px;
  margin: auto;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}

.w-100 {width: 100%}
.text-center {text-align: center;}

.box{
  margin: auto;
  padding: 20px;
  margin: 10px 0;
  background-color: #eee;
}

.loader {
  display: inline-block;
  position: relative;
  width: 20px;
  height: 20px;
}
.loader div {
  position: absolute;
  border: 2px solid #fff;
  opacity: 1;
  border-radius: 50%;
  animation: loader 1s cubic-bezier(0, 0.2, 0.8, 1) infinite;
}
.loader div:nth-child(2) {
  animation-delay: -0.5s;
}
@keyframes loader {
  0% {
    top: 8px;
    left: 8px;
    width: 0;
    height: 0;
    opacity: 1;
  }
  100% {
    top: 0px;
    left: 0px;
    width: 16px;
    height: 16px;
    opacity: 0;
  }
}

.has-error {
  border-bottom-color: red !important;
  border-bottom-width: 2px !important;
}

</style>
