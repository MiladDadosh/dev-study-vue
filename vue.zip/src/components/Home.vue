<template>
  <div>
    <div class="box">
      <div class="search-form">
        <input type="text" v-model="search.input" ref="searchInput" :class="{ 'has-error' : search.isEmpty}">
        <button @click="loadNewImages()">
          {{ searchWord }}
        </button>
        <button @click="clearGallery('Write down your keyword to search for images', true)">X</button>
      </div>
    </div>
    <Gallery :data="gallery" />
    <Paginator @loadMoreImages="loadMoreImages" :galleryCount="gallery.images.length" :totalHits="gallery.totalHits" />
  </div>
</template>

<script>
import axios from 'axios'
import pixabay from '../config/pixabay.js'
import Gallery from './Gallery.vue'
import Paginator from './Paginator.vue'

export default {
  name: 'Home', //name of component

  data() {
    return {
      pixabay,
      search: {
        input: '',
        isLoading: false,
        isEmpty: false
      },
      gallery: {
        images: [],
        message: 'Write down your keyword to search for images',
        totalHits: 0
      },
      page: 1
    }
  },

  // this will run BEFORE component is rendered in virtual dom
  created() {

  },

  // this will run AFTER component is rendered in virtual dom
  mounted() {
    this.$refs.searchInput.focus();
  },

  // where computed properties set
  computed: {
    searchWord() {
      return this.search.isLoading ? 'Searching..' : 'Search'
    },
  },

  // methods that are belongs to this component
  methods: {

    // fetch data from api
    fetch(callback) {

      this.gallery.message = 'Searching..';

      // calling get request via axios
      axios.get(`${this.pixabay.url}?key=${this.pixabay.key}&page=${this.page}&q=${this.search.input}`)
      //getting request
      .then(res => {

        if(res.data.total == 0) {
          this.clearGallery('Ops, There are no images found!, Please try another keyword.', false);
          return;
        }

        let clean_hits = res.data.hits.map(hit => { // map data and get my needs
          return {
            id: hit.id,
            largeImageURL: hit.largeImageURL,
            likes: hit.likes,
            views: hit.views
          }
        });

        this.gallery = {
          images: this.gallery.images.concat(clean_hits), // merge current array with new one
          message: '', // clear message
          totalHits: res.data.totalHits // get total hits
        }

      })
      // catching errors // server errors (404,500...)  [optional]
      .catch(err => {
        console.log(err.message);
      })
      // this always run after then or catch.  [optional]
      .finally( () => {
        callback && typeof callback == 'function' && callback(); // you have callback ? the callback is a function ? okey call it!
      });
    },

    // load more images // listener from Paginator component
    loadMoreImages() {
      this.page = this.page + 1;
      this.fetch(() => {
        // callback after finish fetching
        this.$bus.$emit('loadMoreImagesCompleted'); // clear loader for pagination (component fire event to another component)
      });
    },

    // load new images // for main search 
    loadNewImages() {

      // check if input is empty then style error
      if(this.search.input.length < 1) {
        this.search.isEmpty = true; // run input error handler
        this.$refs.searchInput.focus(); // focus on input
        return;
      }

      this.page = 1; //reset paging
      this.gallery.images = []; // reset images array
      this.search.isLoading = true; // run loader
      this.search.isEmpty = false; // clear input error handler

      this.fetch(() => {
        // callback after finish fetching
        setTimeout(() => {
          this.search.isLoading = false; // clear loader
        }, 500);
      });
    },

    // clear the gallery store data
    clearGallery(msg, clearSearchInput) {
        this.gallery = {
          images: [],
          message: msg,
          totalHits: 0
        }
        clearSearchInput ? this.search.input = '' : null;
        this.search.isEmpty = false; // clear input error handler
        this.$refs.searchInput.focus(); // focus on input
    }

  },

  // list of components that are used in this parent component
  components: {
    // 'Gallery': Gallery, // EX
    Gallery,
    Paginator
  }

}
</script>

<style lang="scss" scoped> // scoped is used to closure style for this component only
  .box {
    display: flex;
    justify-content: center;
    .search-form {
      display: flex;
      input, button {
        outline: none !important;
        cursor: pointer;
        background: #fff;
        padding: 10px;
        font-size: 16px;
      }
      input {
        border: 1px solid #005ac0;
        border-right: 0;
        border-radius: 0;
        border-top-left-radius: 4px;
        border-bottom-left-radius: 4px;
      }
      button {
        border: 1px solid #005ac0;
        border-left: 0;
        border-radius: 0;
        border-top-right-radius: 4px;
        border-bottom-right-radius: 4px;
        &:hover, &:focus {background-color: #f5f5f5;}
      }
      button + button {
        margin-left: 10px;
        border: 1px solid #005ac0;
        border-radius: 4px;
      }

    }
  }
</style>
