<template>
    <div class="box paginator" v-show="galleryCount > 0">
        <button @click="loadMoreImages" :disabled="isDisabled">
            Load more
            <div class="loader" v-if="isLoading"><div></div><div></div></div>
        </button>
        <b> Loaded {{ this.galleryCount }} / {{ this.totalHits }} HITS</b>
    </div>
</template>

<script>

export default {
    name: 'Paginator', //name of component
    props: ['totalHits', 'galleryCount'], // props recived from parent component

    data() {
        return {
            isLoading: false,
        }
    },
    
    created() {
        console.log('paginator created');
    },

    mounted() {
        console.log('paginator mounted');

        this.$bus.$on('loadMoreImagesCompleted', () => { // listen to bus event 
            setTimeout(() => {
                this.isLoading = false;
            }, 500);
        });
    },

    computed: {
        isDisabled() {
            return this.totalHits < 1 || this.totalHits <= this.galleryCount;
        }
    },

    methods: {
        loadMoreImages() {
            this.isLoading = true;
            this.$emit('loadMoreImages');
        }
    }
}
</script>

<style lang="scss" scoped>
    .paginator {
        padding: 20px 10px;
        display: flex;
        align-items: center;
        justify-content: space-between !important;
        button {
            padding: 15px 40px;
            background-color: rgb(0, 90, 192);
            border: none;
            border-radius: 4px;
            color: #fff;
            font-weight: 700;
            font-size: 18px;
            cursor: pointer;
            display: flex;
            align-items: center;
            &:hover, &:focus {
                background-color: darken(rgb(0, 90, 192), 15%);
            }
            &:disabled {
                background-color: #bbb;
                cursor: not-allowed;
            }
        }
    }
</style>
