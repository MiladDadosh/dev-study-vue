<template>
    <div class="images">
        <div class="w-100 text-center">
            <p>{{ data.message }}</p>
        </div>
        <div class="image" v-for="hit in data.images" :key="hit.id">
            <img :src="hit.largeImageURL" alt="" class="img-bg">
            <div class="foot">
                <span class="likes">LIKES: {{hit.likes}}</span>
                <span class="views">VIEWS: {{hit.views}}</span>
            </div>
        </div>
    </div>
</template>

<script>

export default {
    name: 'Gallery', //name of component
    props: ['data'] // props recived from parent component
}
</script>

<style lang="scss" scoped>
    .images {
        display: flex;
        flex-wrap: wrap;
        * {transition: all .3s ease;}
        .image {
            width: 250px;
            height: 200px;
            position: relative;
            margin-bottom: 10px;
            border: 2px solid transparent;
            overflow: hidden;
            &:not(:nth-child(4n+1)) {
            margin-left: 10px;
            }
            .foot {
                display: flex;
                align-items: center;
                justify-content: space-between;
                position: absolute;
                bottom: -100%;
                left: 0;
                width: 100%;
                background-color: rgba(0,0,0,.3);
                color: #fff;
                font-size: 14px;
                padding: 5px;
                box-sizing: border-box;
            }
            .img-bg {
                position: absolute;
                width: 100%;
                height: 100%;
                object-fit: cover;
            }
            &:hover, &:focus {
                border-color: rgb(0, 90, 192);
                .img-bg {
                    transform: scale(1.1);
                }
                .foot {
                    bottom: 0;
                }
            }
        }
    }
</style>
