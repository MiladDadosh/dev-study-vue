export default {
    url: 'https://pixabay.com/api/',
    key: '14048339-cd168954ebb3ad694faa86edc',


    test() {
        alert(2);
    }
}